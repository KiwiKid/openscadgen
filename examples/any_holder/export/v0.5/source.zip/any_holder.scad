include <BOSL2/std.scad>;

$fa = .01;
$fs = $preview ? 5 : 1;
$fn = 200;

thingFrameRounding = 2;
insetThing = "square"; // square round


/// Frame size
frameWallWidth = 5;
frameDepth = 5;

insetPrimarySize = 49;
insetSecondarySize = 49;

// FACEPLATE STYLE
frameWidth = insetPrimarySize + frameWallWidth;
frameHeight = insetSecondarySize + frameWallWidth;
squareFrameSize = [frameDepth,frameWidth,frameHeight];


insetDepth = 6;

insetOffset = frameDepth/2-insetDepth/2+0.01;

// square inset settings
squareInsetSize = [insetDepth, insetPrimarySize, insetSecondarySize];
insetRounding = 8;
smallHookMove = [10, -5,0];
largeHookMove = [15, -5, 0];

// round settings

roundHolderSize = 22;
roundInsertRadius = 20;
roundInsertSize = 20;
roundInsertDepth = 10;

/// PICTURE-RAIL HOOK
// The rail runs along Y.  Adjust these three measurements to suit the rail.
railDepth = 18;
railHeight = 7;
railClearance = 2;
railHookWall = 2;
smallHookRoundMove = [0, 0, 0];

// An inverted J: the holder is the front leg, with a bridge over the rail and
// a short back leg that prevents it lifting away from the rail.
module picture_rail_hook() {
    bridgeDepth = railDepth + railClearance + 2 * railHookWall;
    backLegX = frameDepth / 2 + railDepth + railClearance;

    // Overlap the holder at its top/right edge so both solids are joined.
    translate([frameDepth / 2 - railHookWall, -frameWidth / 2, frameHeight / 2 - railHookWall])
        cuboid([bridgeDepth, frameWidth, railHookWall], anchor=LEFT+FRONT+BOTTOM, rounding=1);

    // Retaining leg behind the rail.
    translate([backLegX, -frameWidth / 2, frameHeight / 2 - railHeight - railHookWall])
        cuboid([railHookWall, frameWidth, railHeight + railHookWall], anchor=LEFT+FRONT+BOTTOM, rounding=1);
}

module attachment() picture_rail_hook();

module holder(insetThing="square"){
    if(insetThing == "square"){
        cuboid(squareFrameSize, rounding=thingFrameRounding) children();
    } else if(insetThing == "round"){
        rotate([0,90,0])
        cyl(r=roundHolderSize, h=frameDepth, rounding=1)
         rotate([0,-90,0])
         move(smallHookRoundMove)
         children();
    } else {
        echo("!!!!!!!!! insetThing is not valid");
    }
}

module any_holder(){
    difference(){
        // GROUP 1: The solid positive shapes to be joined together
        // Enclosing these ensures the holder + attachment pass through cleanly
        union() {
            holder(insetThing=insetThing)
                attachment();
        }
        
        // GROUP 2: The cutters (everything below this point gets subtracted)
        if(insetThing == "square"){
            left(insetOffset)
                cuboid(squareInsetSize, rounding=insetRounding, edges="X");
                
                // cord hole
                down(frameWidth/2)
                right(2)
                cuboid([5,15,10]);
                
        } else if(insetThing == "round"){
        
           rotate([0,90,0])
           //down(roundInsertDepth)
                cyl(r=roundInsertRadius, h=insetDepth+3, rounding1=-2);
                
                  // cord hole
                //down(roundInsertSize)
                //right(-roundInsertDepth*1.3)
                //#cuboid([5,15,10]);
                
        } else {
            echo("!!!!!!!!! insetThing is not valid");
        }
    }
}

any_holder();
