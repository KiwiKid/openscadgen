include <BOSL2/std.scad>;

$fn = 100;

standardHexSize = 6.35;

holderHexSize = 8;
holderHexLength = 55;
holderHexLength2 = 80;

clipHexDownAdjust=  6;

housingHolderUp = 5;

holderHexHoleSize = standardHexSize+0.1;
holderHexHoleHeight = 20;

holeCount = 6;

holeSeperator = holderHexHoleSize/2+3.2;

holeUp = 2 + housingHolderUp;
holeOutFromClip = 17;
holeMove = [40,-holeOutFromClip, holeUp];
holeRotate = [-4,2,35];


holeHelperMove = [-2,-2, -3];

module multi_hex_housing_part(hexLength=10, hexRadius=holderHexSize){
    yrot(90)
    linear_extrude(height = hexLength)
    hexagon(r=hexRadius, anchor=CENTER);
    }
    
    
 connectorSeperator1 = 1.5;
  connectorSeperator2 = 1.6;
  connectorUp = 3;

module multi_hex_housing(){
    //left(holderHexLength/2
             up(connectorUp)
    hull(){
    right(holderHexLength2/2)
    
    xcyl(r=9, h= holderHexLength, anchor=CENTER);
    union(){
    
    
     right((holderHexLength2-holderHexLength)/2){
     /* back(holderHexSize*connectorSeperator1)
        multi_hex_housing_part(hexLength= holderHexLength);
        
*/
        

        
      //  fwd(holderHexSize*connectorSeperator2)
        multi_hex_housing_part(hexLength= holderHexLength);
        }
        
         up(housingHolderUp)
        fwd(holderHexSize*connectorSeperator2)
        multi_hex_housing_part(hexLength= holderHexLength2);
            
        }
        }
        xrot(30)
        down(clipHexDownAdjust)
              right((holderHexLength2-holderHexLength)/2)
    back(holderHexSize*connectorSeperator1)
        multi_hex_housing_part(hexLength= holderHexLength);
        

    
}
module multi_hex_holes(mode="isHoles", holderHexRadius = holderHexHoleSize){

    xcopies(holderHexHoleSize+holeSeperator,holeCount)
    move(holeMove)
    rotate(holeRotate){
    linear_extrude(height = holderHexHoleHeight)
    hexagon(r=holderHexRadius, anchor=CENTER);
       
       if(mode == "isHoles"){

       move(holeHelperMove)
       cyl(r=6, h=10);
       }
    }
}


module multi_hex_drill_attachment(){
    difference(){
    union(){
    
        multi_hex_housing();
    /*    down(11)
        back(1)
        right(0.7)
        left_half()
        multi_hex_holes(mode="isNotHoles", holderHexRadius = holderHexHoleSize+1);*/
        }
        down(7)
        multi_hex_holes(mode="isHoles");
    }
}
multi_hex_drill_attachment();
