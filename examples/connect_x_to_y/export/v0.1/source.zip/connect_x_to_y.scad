include <BOSL2/std.scad>;

$fn = 100;

xShape = "tube";
yShape = "tube";

xHeight = 10;
yHeight = 10;
tubeRadius = 27/2;
tubeConnectorRadius = 31/2;
tubeConnectorHeight = 120;
tubeWall = 3;

height = 10;

enableY = true;
enableX = false;
module x(shape="tube"){
    if(shape == "tube"){
    
        tube(or=tubeRadius, wall=tubeWall, h=xHeight, anchor=BOT);
    } else {
        assert(false, "in x, shape not supported");
    }
}
module y(shape="tube"){
 if(shape == "tube"){
    tube(or=tubeRadius, wall=tubeWall, h=yHeight, anchor=TOP);
    } else {
        assert(false, "in x, shape not supported");
    }
}
module connector(){
    tube(or=tubeConnectorRadius, wall=tubeConnectorRadius-tubeRadius, h=tubeConnectorHeight, anchor=TOP);
    //cyl(r=tubeConnectorRadius, h=tubeConnectorHeight, anchor=TOP);
}
module connect_x_to_y(){
if(enableX){
	x(shape=xShape);
    }
    connector();
    
    down(tubeConnectorHeight)
    if(enableY){
    	y(shape=yShape);
        }
}

connect_x_to_y();
