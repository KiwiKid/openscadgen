CapRack module by lbjessen on Thingiverse: https://www.thingiverse.com/thing:7045946

Summary:
Build as manny modules as you need for your Caps.Remember to print strong structure in your slizer. PLA is the most bridle. If you can - use stronger filaments. PETG or ABS or better Nylon :)Set support to ON. The little nose with hole in needs support of a kind to fit into the next module.
