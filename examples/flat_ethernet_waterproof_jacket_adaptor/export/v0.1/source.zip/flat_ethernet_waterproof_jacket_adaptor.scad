include <BOSL2/std.scad>;

$fn = 100;

module flat_ethernet_waterproof_jacket_adaptor(){
	difference(){
        cyl(r=4, h=1);
        fwd(1)
        cuboid([2,8,10]);
    
    }
}

flat_ethernet_waterproof_jacket_adaptor();
