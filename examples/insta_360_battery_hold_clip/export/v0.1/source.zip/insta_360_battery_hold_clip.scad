include <BOSL2/std.scad>;

$fn = 100;

mode = "stand";

clipThickness = 2;
clipBandHeight= 4; // 10 12
clipRounding = 8; 

wiggleRoom = 0.3;
instaSize = [46.2, 20.8, 113.0]+[wiggleRoom,wiggleRoom,0];
clipSize = [46.2+clipThickness, 20.8+clipThickness, clipBandHeight];

module insta_shape(){

    cuboid(instaSize, anchor=BOT, rounding=clipRounding, edges="Z");
}

module insta_tube(){
#difference(){
	cuboid(clipSize, anchor=BOT, rounding=clipRounding, edges="Z");
    
    //up(clipThickness)
    down(1)
        insta_shape();
    }

}

module insta_360_battery_hold_clip(mode="ring"){

    if(mode == "ring"){
        intersection(){
        insta_tube();
        up(0)
            #cuboid([1000, 1000, clipBandHeight]);
            
        }
    } else if(mode == "stand"){
      //  intersection(){
      insta_tube();
     //   up(0)
     //       cuboid([1000, 1000, 1000]);
            
     //   }

    } else {
        assert(false, "invalid mode");
    }
}



insta_360_battery_hold_clip(mode=mode);
