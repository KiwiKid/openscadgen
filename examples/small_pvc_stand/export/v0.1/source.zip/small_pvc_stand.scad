include <BOSL2/std.scad>;

$fn = 100;

mode = "hexTable";// "pipeSize"

tableSize = [20,20,3];

pvcPipeRadius = 2.6;
pvcPipeWallSize = 3;

module pvcCutoutHole(){
	tube(or=pvcPipeRadius,
        w=pvcPipeWallSize,
        h=10
        );

}

module small_pvc_stand(){
    cuboid(tableSize, rounding=2);
}

if(mode == "pipeSize"){


small_pvc_stand();

}else if(mode == "hexTable") {
    small_pvc_stand();
}
